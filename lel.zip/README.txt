Information for Ashes2007's automatic file backup program.
This is a highly configurable software for saving youe work. 
The system is currently in the V(0.56) state.
	Current functions:
Saving files based on time.
Deleting old backup files.
Configurable.
	WIP functions:
Log reading/ log printing (Broken due to recent change, contact me on github or discord for a workaround)
Multiple user configuration ability (Should work, just not tested)
	Next version's functions:
Sending backed up files to a dated .ZIP periodically
Background running (Functional with slight tweak tweak)
Github updater?
	How to install:
Simply double click the included .exe, and it will install itself. This takes a few milliseconds, and will have to be repeated for each user.
	How to use:
Click the included .exe, and follow the onscreen instructions. There are a few things that will harmlessly shut down the program immediately. Basically don't press enter with a blank screen. (This will be fixed in V0.56)
	How to uninstall:
1:1) Contact me on discord for the uninstaller (Couldn't be included due to complications)
	Option 2:
2:1) Type "regedit" into the search bar and open registry editor.
2:2) Type "Computer\HKEY_CURRENT_USER\Software\Backupsystemprefs" into the bar on the top of the registry editor (without quotes)
2:3) Right click "Backupsystemprefs" and click delete.
2:4) Delete the parent folder of this .txt

Contact me on discord for additional information.